import os
import logging
import sys
import json
from supabase import create_client, Client

# Script-Verzeichnis zum Pfad hinzufügen
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

# Lade .env-Datei
try:
    from dotenv import load_dotenv
    env_path = os.path.join(script_dir, '.well-known', '.env')
    load_dotenv(env_path)
    print(f"Umgebungsvariablen aus {env_path} geladen")
except Exception as e:
    print(f"Fehler beim Laden der Umgebungsvariablen: {e}")

# Supabase-Konfiguration
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    print("WARNUNG: SUPABASE_URL oder SUPABASE_KEY nicht gesetzt!")

try:
    supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
except Exception as e:
    print(f"Fehler beim Initialisieren des Supabase-Clients: {e}")
    supabase = None

# Logging konfigurieren
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def speichere_daten(tabelle: str, daten: list):
    """Speichert oder aktualisiert Daten in Supabase."""
    if not supabase:
        logger.error("Supabase-Client ist nicht initialisiert")
        return
    
    logger.info(f"Starte Speicherung von {len(daten)} Einträgen in Tabelle '{tabelle}'")
    
    if not daten:
        logger.warning(f"Keine Daten zum Speichern in Tabelle '{tabelle}'")
        return
        
    # Zeige den ersten Datensatz zum Debugging
    if daten:
        logger.debug(f"Erster Datensatz für '{tabelle}': {json.dumps(daten[0], indent=2)}")
    
    success_count = 0
    error_count = 0
    
    try:
        for i, eintrag in enumerate(daten):
            eintrag_id = eintrag.get("id")
            if not eintrag_id:
                logger.warning(f"Eintrag {i} hat keine ID, überspringe")
                continue
            
            # Versuche zuerst, den Eintrag zu finden
            try:
                logger.debug(f"Suche nach ID {eintrag_id} in Tabelle {tabelle}")
                
                # Die gesamte Tabelle holen und manuell filtern (robuster als .eq())
                response = supabase.table(tabelle).select("*").execute()
                
                # Manuell nach der ID filtern
                vorhandener_eintrag = None
                for item in response.data:
                    if item.get('id') == eintrag_id:
                        vorhandener_eintrag = item
                        break
                
                if vorhandener_eintrag:
                    logger.info(f"Aktualisiere Eintrag {eintrag_id} in {tabelle}")
                    # Wir verwenden die tatsächliche ID aus der Datenbank
                    update_response = supabase.table(tabelle).update(eintrag).eq("id", eintrag_id).execute()
                    logger.debug(f"Update-Antwort: {update_response.data}")
                    success_count += 1
                else:
                    logger.info(f"Füge neuen Eintrag {eintrag_id} zu {tabelle} hinzu")
                    insert_response = supabase.table(tabelle).insert(eintrag).execute()
                    logger.debug(f"Insert-Antwort: {insert_response.data}")
                    success_count += 1
            except Exception as inner_e:
                logger.error(f"Fehler bei der Abfrage/Update für ID {eintrag_id} in {tabelle}: {str(inner_e)}")
                error_count += 1
                
                # SQL-Debug-Ausgabe versuchen
                try:
                    if hasattr(inner_e, 'details') and inner_e.details:
                        logger.error(f"SQL-Fehlerdetails: {inner_e.details}")
                except:
                    pass
                
                # Fallback: Versuche einfach einen neuen Eintrag zu erstellen
                try:
                    logger.info(f"Fallback: Versuche Eintrag {eintrag_id} zu erstellen")
                    fallback_response = supabase.table(tabelle).insert(eintrag).execute()
                    logger.debug(f"Fallback-Insert-Antwort: {fallback_response.data}")
                    success_count += 1
                except Exception as insert_e:
                    logger.error(f"Auch Fallback-Erstellung fehlgeschlagen: {str(insert_e)}")
                    
                    # Versuche, nur die wichtigsten Felder zu speichern
                    try:
                        logger.info(f"Letzter Versuch: Erstelle minimalen Eintrag für {eintrag_id}")
                        minimal_entry = {"id": eintrag_id}
                        for key in ["name", "titel", "rechnung", "status"]:
                            if key in eintrag:
                                minimal_entry[key] = eintrag[key]
                        minimal_response = supabase.table(tabelle).insert(minimal_entry).execute()
                        logger.debug(f"Minimal-Insert-Antwort: {minimal_response.data}")
                        success_count += 1
                    except Exception as minimal_e:
                        logger.error(f"Auch minimale Erstellung fehlgeschlagen: {str(minimal_e)}")
                        error_count += 1
    except Exception as e:
        logger.error(f"Allgemeiner Fehler beim Speichern in {tabelle}: {str(e)}")
        error_count += len(daten)
    
    logger.info(f"Speicherung in '{tabelle}' abgeschlossen: {success_count} erfolgreich, {error_count} fehlerhaft")

def speichere_aufgaben(aufgaben):
    """Speichert Aufgaben in Supabase."""
    logger.info(f"Speichere {len(aufgaben)} Aufgaben")
    speichere_daten("aufgaben", aufgaben)

def speichere_offerten(offerten):
    """Speichert Offerten in Supabase."""
    logger.info(f"Speichere {len(offerten)} Offerten")
    speichere_daten("notion_offerten", offerten)

def speichere_rechnungen(rechnungen):
    """Speichert Rechnungen in Supabase."""
    logger.info(f"Speichere {len(rechnungen)} Rechnungen")
    speichere_daten("notion_rechnungen", rechnungen)

def speichere_meetings(meetings):
    """Speichert Meetings in Supabase."""
    logger.info(f"Speichere {len(meetings)} Meetings")
    speichere_daten("notion_meetings", meetings)

def get_aufgabe_by_notion_id(notion_id):
    """Sucht eine Aufgabe anhand ihrer Notion-ID."""
    if not supabase:
        logger.error("Supabase-Client ist nicht initialisiert")
        return None
        
    try:
        # Verwende notion_id anstelle von id
        response = supabase.table("aufgaben").select("*").eq("notion_id", notion_id).execute()
        return response.data[0] if response.data else None
    except Exception as e:
        logger.error(f"Fehler beim Suchen nach Notion-ID: {str(e)}")
        return None

def update_aufgabe(id, data):
    """Aktualisiert eine bestehende Aufgabe."""
    if not supabase:
        logger.error("Supabase-Client ist nicht initialisiert")
        return None
        
    return supabase.table("aufgaben").update(data).eq("id", id).execute()

def create_aufgabe(data):
    """Erstellt eine neue Aufgabe."""
    if not supabase:
        logger.error("Supabase-Client ist nicht initialisiert")
        return None
        
    return supabase.table("aufgaben").insert(data).execute()

def check_table_structure(table_name):
    """Überprüft die Struktur einer Tabelle."""
    if not supabase:
        logger.error("Supabase-Client ist nicht initialisiert")
        return False
        
    try:
        response = supabase.table(table_name).select('*').limit(1).execute()
        if response.data:
            columns = list(response.data[0].keys())
            logger.info(f"Tabelle {table_name} hat folgende Spalten: {columns}")
        else:
            logger.info(f"Tabelle {table_name} existiert, hat aber keine Daten")
        return True
    except Exception as e:
        logger.error(f"Fehler beim Lesen der Tabelle {table_name}: {e}")
        return False

def test_connection():
    """Testet die Verbindung zu Supabase."""
    if not supabase:
        logger.error("Supabase-Client ist nicht initialisiert")
        return False
        
    try:
        response = supabase.table('aufgaben').select('*').limit(1).execute()
        logger.info("Supabase-Verbindung erfolgreich.")
        return True
    except Exception as e:
        logger.error(f"Supabase-Verbindung fehlgeschlagen: {e}")
        return False

def test_direct_insert(table_name):
    """Testet einen direkten Insert in eine Tabelle."""
    if not supabase:
        logger.error("Supabase-Client ist nicht initialisiert")
        return False
        
    try:
        # Erstelle einen Test-Eintrag
        test_id = "00000000-0000-0000-0000-000000000001"
        test_data = {
            "id": test_id,
            "name": "Test Eintrag",
            "beschreibung": "Test Beschreibung",
            "status": "Test Status"
        }
        
        logger.info(f"Teste direkten Insert in Tabelle {table_name}...")
        response = supabase.table(table_name).insert(test_data).execute()
        
        logger.info(f"Insert erfolgreich: {response.data}")
        
        # Lösche den Test-Eintrag wieder
        delete_response = supabase.table(table_name).delete().eq("id", test_id).execute()
        logger.info(f"Löschung erfolgreich: {delete_response.data}")
        
        return True
    except Exception as e:
        logger.error(f"Fehler beim Testen des direkten Inserts: {e}")
        return False

if __name__ == "__main__":
    # Teste die Verbindung und Tabellenstrukturen
    if test_connection():
        check_table_structure('aufgaben')
        check_table_structure('notion_offerten')
        check_table_structure('notion_meetings')
        check_table_structure('notion_rechnungen')
        
        # Teste direkte Inserts
        test_direct_insert('notion_offerten')
        test_direct_insert('notion_meetings')
    else:
        logger.error("Konnte keine Verbindung zu Supabase herstellen!")
